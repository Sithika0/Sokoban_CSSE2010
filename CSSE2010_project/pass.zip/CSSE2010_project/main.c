/*
 * CSSE2010_project.c
 *
 * Created: 5/10/2024 12:15:10 PM
 * Author : sithika
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

